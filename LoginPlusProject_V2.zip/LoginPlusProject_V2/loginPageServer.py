import bcrypt
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, BooleanField, TextAreaField
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError
import csv
from itertools import count
from os import read
from os.path import basename
from tabulate import tabulate

# for email verification and reset passowrd
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from flask import Flask
from flask.globals import session


from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.ext.declarative import base
from sqlalchemy.sql.elements import Null
from sqlalchemy_utils import database_exists


from flask_bcrypt import Bcrypt


from flask_login import LoginManager, login_user, UserMixin, current_user, logout_user, login_required


from flask import render_template, url_for, flash, redirect, request, abort

from flask_mail import Message
from datetime import datetime

app = Flask(__name__)

'''
random
>>> import secrets
>>> secrets.token_hex(16)
'c69b179f3318df71f0b803b51a1dd383'
'''
app.config['SECRET_KEY'] = 'c69b179f3318df71f0b803b51a1dd383'


app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///./userDB.db'

l1 = ['Supply chain management', 'Decision modelling',
      'Statistics for management', 'Ergonomics', 'Marketing Management']
l2 = ['Power Electronics', 'Hybrid Electric vehicles',
      'Power system', 'Internet of things', 'High voltage']

# create database
dbUser = SQLAlchemy(app)
db = SQLAlchemy(app)
# for hasshed password
bcrypt = Bcrypt(app)
# for login and log off
login_manager = LoginManager(app)
login_manager.login_view = 'login_func'
login_manager.login_message_category = 'info'


@ app.route('/')
@ app.route('/home')
def homepage_func():
    if current_user.is_authenticated:
        return render_template('homepage.html', title_from_python="Attendance Management"), 302
    else:
        return render_template('homepage.html', title_from_python="Attendance Management")


@app.route('/register', methods=['GET', 'POST'])
def register_func():
    if current_user.is_authenticated:
        flash(f'Logout First', 'warning')
        return redirect(url_for('homepage_func'))
    form = RegistrationFrom()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(
            form.password.data).decode('utf-8')
        user = User(username=form.username.data,
                    email=form.email.data, password=hashed_password, actualName=form.actualName.data)
        dbUser.session.add(user)
        dbUser.session.commit()
        flash(f'Your account has been created!', 'success')
        return redirect(url_for('login_func'))
    return render_template('register.html', title='Registration', form=form)


@app.route('/login', methods=['GET', 'POST'])
def login_func():
    # print('Mehtod 1')

    if current_user.is_authenticated:
        # print('Mehtod x')
        flash(f'Logout First', 'warning')
        return redirect(url_for('homepage_func'))
    form = LoginForm()
    # print(dir(form))
    # print(form.data)
    # print(form.email.data, form.password.data, form.remember.data)
    # print(dir(form))
    # print(form.hidden_tag())
    # print(dir(form.meta))
    # print(form.meta.csrf_context)
    if form.validate_on_submit():
        print('Mehtod 2')
        user = User.query.filter_by(email=form.email.data).first()
        if user != None and bcrypt.check_password_hash(user.password, form.password.data):
            # login with rememerbye
            login_user(user, remember=form.remember.data)
            flash('You have been logged in', 'success')
            next_page = request.args.get('next')
            if next_page == None:
                return redirect(url_for('homepage_func')), 302
            else:
                return redirect(next_page), 302
        else:
            flash('Login Unsuccessful. Please check email and password', 'danger')
            return render_template('login.html', title='Login', form=form)

        # flash(f'login okay summa', 'success')
    return render_template('login.html', title='Login', form=form)


@app.route('/logout')
def logout_func():
    if current_user.is_authenticated:
        logout_user()
        flash(f'You have been logged out successfully', 'success')
        return redirect(url_for('homepage_func'))
    else:
        flash(f'Login First', 'warning')
        return redirect(url_for('login_func'))


@app.route('/account', methods=['GET', 'POST'])
@login_required
def account_func():
    form = UpdateAccountForm()
    if form.validate_on_submit():
        current_user.actualName = form.actualName.data
        current_user.username = form.username.data
        current_user.email = form.email.data
        dbUser.session.commit()
        flash('Your account has been updated', 'success')
        return redirect(url_for('account_func'))
    elif request.method == 'GET':
        form.actualName.data = current_user.actualName
        form.username.data = current_user.username
        form.email.data = current_user.email
    return render_template('account.html', title='Account', form=form)


@app.route('/adminPage')
@login_required
def admin_func():
    if current_user.is_authenticated and (current_user.username == 'admin' or current_user.username == 'anoj'):
        UserList = User.query.all()
        newUserList = []
        for i in UserList:
            newUserList.append((i.actualName, i.username, i.email))
        return render_template('adminPage.html', title='ADMINSTRATION', listU=newUserList)
    else:
        flash(f'You should be an admin to access this page!', 'danger')
        return redirect(url_for('homepage_func'))


@app.route('/displayAttendance', methods=['GET', 'POST'])
@login_required
def disp_attendance_func():
    if request.method == 'GET':
        return render_template('displayAttendance.html')
    else:
        tbName = request.form['tableName']
        tableList = Basedb.query.filter_by(
            baseName=tbName).first()
        st = ''
        # st = str(tableList).replace('\n', "<br>")
        headersL = ['StudentID', 'StudentName', 'Absent or Present']
        for j in range(tableList.periods.count()):
            peroidTb = tableList.periods[j]
            st = st + '<center><h1>'+tbName+' - ' + \
                peroidTb.periodTitle+' (HeadCount = ' + \
                str(peroidTb.headCount)+')</h1></center></br>'
            myLis = []
            for i in range(peroidTb.attendance.count()):
                myLis.append([str(peroidTb.attendance[int(i)].studentID), str(peroidTb.attendance[int(
                    i)].studentName), str(peroidTb.attendance[int(i)].presentOrAbsent)])
            st = st + tabulate(myLis, headers=headersL, tablefmt="html")

        return render_template('displayAttendance.html', argPassVal=st, listSelected=tbName)


@ app.route('/displayTable', methods=['GET', 'POST'])
@ login_required
def displayTable_func():
    if request.method == 'GET':
        return render_template('displayTable.html')
    else:
        tbName = request.form['tableName']
        tableList = Basedb.query.filter_by(
            baseName=tbName).first()
        st = ''
        # st = str(tableList).replace('\n', "<br>")
        headersL = ['StudentID', 'StudentName', 'Absent or Present']
        for j in range(tableList.periods.count()):
            peroidTb = tableList.periods[j]
            st = st + '<center><h1>'+tbName+' - ' + \
                peroidTb.periodTitle+' (HeadCount = ' + \
                str(peroidTb.headCount)+')</h1></center></br>'
            myLis = []
            for i in range(peroidTb.attendance.count()):
                myLis.append([str(peroidTb.attendance[int(i)].studentID), str(peroidTb.attendance[int(
                    i)].studentName), str(peroidTb.attendance[int(i)].presentOrAbsent)])
            st = st + tabulate(myLis, headers=headersL, tablefmt="html")

        return render_template('displayTable.html', argPassVal=st, checkedRadio=tbName)


# @ app.route('/setHeadCount/<className>/<periodNO>/<headCount>', methods=['GET'])
# def setHeadCount_func(className, periodNO, headCount):
#     if request.method == 'GET':
#         baseTb = Basedb.query.filter_by(baseName=className).first()
#         if baseTb != None:
#             if 1 <= int(periodNO) and int(periodNO) <= 5:
#                 peroidTb = baseTb.periods[int(periodNO) - 1]
#                 peroidTb.headCount = headCount
#                 db.session.commit()
#                 return "SUCCESS"
#             else:
#                 return "No peroids in that range"
#         else:
#             return "No class Name"
#     else:
#         return 'some issue'


# @app.route('/getHeadCount/<className>/<periodNO>', methods=['GET'])
# @login_required
# def getHeadCount_func(className, periodNO):
#     if request.method == 'GET':
#         baseTb = Basedb.query.filter_by(baseName=className).first()
#         if baseTb != None:
#             if 1 <= int(periodNO) and int(periodNO) <= 5:
#                 peroidTb = baseTb.periods[int(periodNO) - 1]
#                 return str(peroidTb.headCount)
#             else:
#                 return "No peroids in that range"
#         else:
#             return "No class Name"
#     else:
#         return 'some issue'


# @ app.route('/getIndividualStudentAttendace/<className>/<periodNO>/<studentID>', methods=['GET'])
# def getIndividualStudentAttendace_func(className, periodNO, studentID):
#     if request.method == 'GET':
#         baseTb = Basedb.query.filter_by(baseName=className).first()
#         if baseTb != None:
#             if 1 <= int(periodNO) and int(periodNO) <= 5:
#                 peroidTb = baseTb.periods[int(periodNO) - 1]
#                 if peroidTb != None:
#                     # return str(peroidTb.attendance[int(studentID)].studentID)+' - ' + str(peroidTb.attendance[int(studentID)].studentName)+' - '+str(peroidTb.attendance[int(studentID)].presentOrAbsent)
#                     headersL = ['StudentID',
#                                 'StudentName', 'Absent or Present']
#                     myLis = []

#                     myLis.append([str(peroidTb.attendance[int(studentID)].studentID), str(peroidTb.attendance[int(
#                         studentID)].studentName), str(peroidTb.attendance[int(studentID)].presentOrAbsent)])

#                     # return tabulate(myLis, headers=headersL, tablefmt="html")
#                     return str(peroidTb.attendance[int(studentID)].presentOrAbsent)

#                 # return "something"
#                 else:
#                     return "Period table issue"
#             else:
#                 return "No peroids in that range"
#         else:
#             return "No class Name"
#     else:
#         return 'some issue'

# implementing calculation to update headcount based on absentprsent thingie


def updateHeadCount(periodTb):
    pCount = 0
    for i in range(periodTb.attendance.count()):
        if periodTb.attendance[i].presentOrAbsent == 'P':
            pCount = pCount + 1
    periodTb.headCount = pCount
    db.session.commit()
    print(periodTb.headCount)


@ app.route('/setIndividualStudentAttendace/<className>/<periodNO>/<studentID>/<PorA>', methods=['GET'])
def setIndividualStudentAttendace_func(className, periodNO, studentID, PorA):
    if request.method == 'GET':
        baseTb = Basedb.query.filter_by(baseName=className).first()
        if baseTb != None:
            if 1 <= int(periodNO) and int(periodNO) <= 5:
                peroidTb = baseTb.periods[int(periodNO) - 1]
                if peroidTb != None:
                    if PorA in ['A', 'P']:

                        peroidTb.attendance[int(
                            studentID) - 1].presentOrAbsent = PorA
                    else:
                        peroidTb.attendance[int(
                            studentID) - 1].presentOrAbsent = 'Invalid'
                    db.session.commit()
                    updateHeadCount(peroidTb)
                    return "SUCCESS"
                    # return "something"
                else:
                    "Period table issue"
            else:
                return "No peroids in that range"
        else:
            return "No class Name"
    else:
        return 'some issue'


# @ app.route('/setPeriodAttendance/<className>/<periodNO>/<PorAasList>', methods=['GET'])
# def setPeriodAttendance_func(className, periodNO, PorAasList):
#     if request.method == 'GET':
#         baseTb = Basedb.query.filter_by(baseName=className).first()
#         if baseTb != None:
#             if 1 <= int(periodNO) and int(periodNO) <= 5:
#                 peroidTb = baseTb.periods[int(periodNO) - 1]
#                 lis = PorAasList.split('-')
#                 for i in range(len(lis)):
#                     peroidTb.attendance[i].presentOrAbsent = lis[i]
#                 db.session.commit()
#                 return "SUCCESS"
#                 # return "something"

#             else:
#                 return "No peroids in that range"
#         else:
#             return "No class Name"
#     else:
#         return 'some issue'


# @ app.route('/getPeriodAttendance/<className>/<periodNO>', methods=['GET'])
# def getPeriodAttendance_func(className, periodNO):
#     if request.method == 'GET':
#         baseTb = Basedb.query.filter_by(baseName=className).first()
#         if baseTb != None:
#             if 1 <= int(periodNO) and int(periodNO) <= 5:
#                 peroidTb = baseTb.periods[int(periodNO) - 1]
#                 st = ''
#                 # for i in range(peroidTb.attendance.count()):
#                 #     st = st + str(peroidTb.attendance[i].presentOrAbsent)+'-'

#                 # return st[0:len(st)-1]

#                 st = st + '<center><h1>'+className+' - ' + \
#                     peroidTb.periodTitle+' (HeadCount = ' + \
#                     str(peroidTb.headCount)+')</h1></center></br>'
#                 headersL = ['StudentID', 'StudentName', 'Absent or Present']
#                 myLis = []
#                 for i in range(peroidTb.attendance.count()):
#                     myLis.append([str(peroidTb.attendance[int(i)].studentID), str(peroidTb.attendance[int(
#                         i)].studentName), str(peroidTb.attendance[int(i)].presentOrAbsent)])

#                 st = st + tabulate(myLis, headers=headersL, tablefmt="html")
#                 return st
#                 # return "something"

#             else:
#                 return "No peroids in that range"
#         else:
#             return "No class Name"
#     else:
#         return 'some issue'


# @ app.route('/getClassAttendance/<className>', methods=['GET'])
# def getClassAttendance_func(className):
#     if request.method == 'GET':
#         baseTb = Basedb.query.filter_by(baseName=className).first()
#         if baseTb != None:
#             st = ''
#             # for i in range(baseTb.periods.count()):
#             #     peroidTb = baseTb.periods[i]
#             #     for j in range(peroidTb.attendance.count()):
#             #         st = st + str(peroidTb.attendance[j].presentOrAbsent)+'-'
#             #     st = st[0:len(st)-1] + '*'
#             # return st[0:len(st)-1]
#             headersL = ['StudentID', 'StudentName', 'Absent or Present']
#             for j in range(baseTb.periods.count()):
#                 peroidTb = baseTb.periods[j]
#                 st = st + '<center><h1>'+className+' - ' + \
#                     peroidTb.periodTitle+' (HeadCount = ' + \
#                     str(peroidTb.headCount)+')</h1></center></br>'
#                 myLis = []
#                 for i in range(peroidTb.attendance.count()):
#                     myLis.append([str(peroidTb.attendance[int(i)].studentID), str(peroidTb.attendance[int(
#                         i)].studentName), str(peroidTb.attendance[int(i)].presentOrAbsent)])
#                 st = st + tabulate(myLis, headers=headersL, tablefmt="html")
#             return st
#         else:
#             return "No class Name"
#     else:
#         return 'some issue'


# extra routes

@app.route('/getClassNames', methods=['GET'])
def getClassName_func():
    st = ''
    if request.method == 'GET':
        allTables = Basedb.query.all()
        for i in range(len(allTables)):
            st = st + allTables[i].baseName+','
        return st[0:len(st)-1]
    else:
        return ""


@app.route('/getSubjectNames/<className>', methods=['GET'])
def getSubjectNames_func(className):
    if request.method == 'GET':
        st = ''

        tableList = Basedb.query.filter_by(baseName=className).first()
        if tableList != None:
            for j in range(tableList.periods.count()):
                peroidTb = tableList.periods[j]
                st = st + peroidTb.periodTitle + ','
            return st[0:len(st)-1]
        return ""
    else:
        return ""


@app.route('/getSubjectDetails/<className>/<subjectNo>', methods=['GET'])
def getSubjectDetails_func(className, subjectNo):
    if request.method == 'GET':
        tableList = Basedb.query.filter_by(baseName=className).first()
        peroidTb = tableList.periods[int(subjectNo)-1]
        rollnost = ''
        namest = ''
        attendancest = ''
        for i in range(peroidTb.attendance.count()):
            rollnost = rollnost + \
                str(peroidTb.attendance[int(i)].studentID) + ','
            namest = namest + \
                str(peroidTb.attendance[int(i)].studentName) + ','
            attendancest = attendancest + \
                str(peroidTb.attendance[int(i)].presentOrAbsent) + ','
        retval = rollnost[0:len(rollnost)-1] + '-' + namest[0:len(namest) -
                                                            1] + '-' + attendancest[0:len(attendancest)-1]+'-'+str(peroidTb.headCount)
        return retval
    else:
        return ""


@app.route('/getUserDetails/<emailID>', methods=['GET'])
def getUserDetails_func(emailID):
    # print("gumma")
    # print(emailID)
    if request.method == 'GET':
        userDb = User.query.filter_by(email=emailID).first()
        st = userDb.username+','+userDb.email+','+userDb.actualName
        # print(st)
        return st
    else:
        return ""

# forms


class RegistrationFrom(FlaskForm):
    actualName = StringField('Name', validators=[
        DataRequired(), Length(min=5, max=35)])
    username = StringField('Username', validators=[
        DataRequired(), Length(min=2, max=20)])

    email = StringField('Email', validators=[DataRequired(), Email()])

    password = PasswordField('Password', validators=[DataRequired()])
    confirm_password = PasswordField('Confirm Password', validators=[
        DataRequired(), EqualTo('password')])
    submit = SubmitField('Sign up')

    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user != None:
            print("aiyoo")
            raise ValidationError('Username taken')

    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user != None:
            raise ValidationError('Email already used')


class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')


class UpdateAccountForm(FlaskForm):
    actualName = StringField('Name', validators=[
        DataRequired(), Length(min=5, max=35)])
    username = StringField('Username', validators=[
        DataRequired(), Length(min=2, max=20)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    submit = SubmitField('Update')
    # for unique username and  email

    def validate_username(self, username):
        if username.data != current_user.username:
            user = User.query.filter_by(username=username.data).first()
            if user != None:
                raise ValidationError('Username taken')

    def validate_email(self, email):
        if email.data != current_user.email:
            user = User.query.filter_by(email=email.data).first()
            if user != None:
                raise ValidationError('Email already used')


# database for users
class User(dbUser.Model, UserMixin):
    id = dbUser.Column(dbUser.Integer, primary_key=True)
    actualName = dbUser.Column(dbUser.String(35), unique=False, nullable=False)
    username = dbUser.Column(dbUser.String(20), unique=True, nullable=False)
    email = dbUser.Column(dbUser.String(120), unique=True, nullable=False)
    password = dbUser.Column(dbUser.String(60), nullable=False)

    # for password reset etc
    # def get_reset_token(self, expires_sec=1800):
    #     s = Serializer(app.config['SECRET_KEY'], expires_sec)
    #     return s.dumps({'user_id': self.id}).decode('utf-8')

    # @staticmethod
    # def verify_reset_token(token):
    #     s = Serializer(app.config['SECRET_KEY'])
    #     try:
    #         user_id = s.loads(token)['user_id']
    #     except:
    #         return None
    #     return User.query.get(user_id)

    def __repr__(self):
        return f"User('{self.actualName}','{self.username}', '{self.email}')"


class Basedb(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    baseName = db.Column(db.String(30), unique=True, nullable=False)

    periods = db.relationship("Perioddb", backref='basedb',
                              lazy='dynamic')

    def __repr__(self):
        st = 'BaseName = ' + self.baseName + '\n'
        for i in range(self.periods.count()):
            st = st + str(self.periods[i])+'\n'
        return st


class Perioddb(db.Model):
    # __tablename__ = 'periodSlot'
    id = db.Column(db.Integer, primary_key=True)
    periodTitle = db.Column(db.String(12), nullable=False,
                            default='Period_x')
    headCount = db.Column(db.Integer, nullable=False, default=0)

    attendance = db.relationship("Attendancedb", backref='perioddb',
                                 lazy='dynamic')
    basedb_id = db.Column(db.Integer, db.ForeignKey('basedb.id'))

    def __repr__(self):
        st = 'Peroid Title :' + self.periodTitle + \
            ' HeadCount = '+str(self.headCount)+' \n'
        for i in range(self.attendance.count()):
            st = st + 'Student ID : ' + str(self.attendance[i])+'\n'

        return st


class Attendancedb(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    studentID = db.Column(db.String(12), nullable=False, default='M190XXXME')
    studentName = db.Column(db.String(50), nullable=False, default='no name')
    presentOrAbsent = db.Column(db.String(12), nullable=False, default='A')

    perioddb_id = db.Column(db.Integer, db.ForeignKey('perioddb.id'))

    def __repr__(self):
        st = ''
        st = self.studentID + ':' + self.studentName + ' : '+self.presentOrAbsent
        return st


# Extention for login to work
@ login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


def createDBUsers():
    dbUser.drop_all()
    dbUser.create_all()
    hashed_password = bcrypt.generate_password_hash(
        'password').decode('utf-8')
    userAdmin = User(username='admin', email='admin@admin.com',
                     password=hashed_password, actualName='ADMIN')
    dbUser.session.add(userAdmin)
    dbUser.session.commit()


def createClasses(className=''):
    with open(className+'.csv', newline='\n') as f:
        reader = csv.reader(f)
        data = list(reader)
    # print(len(data))

    edtINS = Basedb(baseName=className)
    for i in range(5):
        if className == 'IEM':
            p = Perioddb(periodTitle=l1[i])
        else:
            p = Perioddb(periodTitle=l2[i])
        for j in range(len(data)):
            # print(data[j][1])
            a = Attendancedb(
                studentID=data[j][0], studentName=data[j][1], presentOrAbsent='A')
            p.attendance.append(a)
        edtINS.periods.append(p)
    db.session.add(edtINS)
    db.session.commit()


if __name__ == '__main__':
    print("\n*******************App started*****************\n")

    # createDBUsers()
    # print(User.query.all())

    # remove after finalization
    # db.drop_all()
    # db.create_all()
    # createClasses('IEM')
    # createClasses('IPA')
    # print(Basedb.query.all())

    app.run(debug=True, host='0.0.0.0')
    # app.run(debug=True, host='127.0.0.1')
